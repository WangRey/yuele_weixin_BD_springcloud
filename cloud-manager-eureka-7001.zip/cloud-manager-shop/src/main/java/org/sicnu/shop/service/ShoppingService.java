package org.sicnu.shop.service;

public interface ShoppingService {
    void buy(String amount,String phone);
}
